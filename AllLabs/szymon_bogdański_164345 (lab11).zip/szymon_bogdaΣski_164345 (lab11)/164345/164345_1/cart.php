<?php
// ustawienie licznika ilosci produktow w koszyku
if (!isset($_SESSION['count']))
{
    $_SESSION['count'] = 1;
} else {
    $_SESSION['count']++;
}

$nr = $_SESSION['count'];  // nadanie numeru dla produktu w koszyku

// zapisanie danych produktow w tablicy 2 wymiarowej - reszte pobierzemy po idProduktu z bazy
$prod[$nr]['idProd'] = $idProd;

?>