<!DOCTYPE html>
<html>

<head>
<style>
/*body {
	background-image: url("background.jpg");
	background-size: cover;
	background-repeat: no-repeat;
	background-color: navy;
	color: white;
	} */
h1 {
	color: gray;
	margin-left: 40px;
	}
</style>

<link rel="stylesheet" type="text/css" href="podstrony/style.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="podstrony/kolorujtlo.js" type="text/javascript"></script>

<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Language" content="pl" />
<meta name="Author" content="Szymon Bogdański" />
<title>Moje hobby to tworzenie gier komputerowych</title>
</head>

<body>

<?php
include("cfg.php");
include("showpage.php");
include("admin/admin.php");
include("contact.php");
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
/* po tym komentarzu będzie kod do dynamicznego ładowania stron */
//$strona = "podstrony/glowna.html";
//include($strona);
if($_GET['idp']=='0'){
	echo PokazPodstrone(1);
} elseif($_GET['idp']=='1'){
	echo PokazPodstrone(2);
} elseif($_GET['idp']=='2'){
	echo PokazPodstrone(3);
} elseif($_GET['idp']=='3'){
	echo PokazPodstrone(4);
} elseif($_GET['idp']=='4'){
	echo PokazPodstrone(5);
} elseif($_GET['idp']=='5'){
	echo PokazPodstrone(6);

} elseif($_GET['idp']=='6'){
	echo PokazPodstrone(7);
} else {
	echo PokazPodstrone(1);
}
echo FormularzLogowania();
ListaPodstron();
//echo EdytujPodstrone();
//echo DodajPodstrone();
//include($strona);
echo PokazKontakt();
WyslijMailaKontakt("123@wp.pl");
PrzypomnijHaslo("123@wp.pl");
?>

<?php
$nr_indeksu = '164345';
$nrGrupy = '1';

echo 'Autor: Szymon Bogdański '. $nr_indeksu.' grupa: '. $nrGrupy.'<br/><br/>';
?>

</body>
</html>