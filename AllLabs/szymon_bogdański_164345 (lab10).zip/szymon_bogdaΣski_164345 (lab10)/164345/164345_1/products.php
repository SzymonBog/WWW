<?php
function PokazProdukty()
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "SELECT * FROM produkty LIMIT 100";
    $result = mysqli_query($link, $query);

    while($row = mysqli_fetch_array($result))
    {
        $curid = $row['id'];
        $query1 = "SELECT nazwa FROM categories where id='$curid'";
        $kat = mysqli_query($link, $query1);
        echo $row['id'].' '.$row['tytul'].' <br />';
        echo $row['opis'].' '.$row['dataUtworzenia'].' '.$row['dataModyfikacji'].' '.$row['dataWygasniecia'].' <br />';
        echo $row['cenaNetto'].' '.$row['podatekVAT'].' <br />';
        echo $row['iloscDostepnychSztuk'].' '.$row['dostepnosc'].' '.$row['kategoria'].' '.$row['gabaryt'].' <br />';  // kategoria INT
        echo $row['zdjecie'].' <br />';
    }
}

function EdytujProdukt()
{
    $wynik = '
    <div class="edycja">
        <h1 class="heading">Edytuj Produkt:</h1>
            <div class="edycja">
            <form method="post" name"EditForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="edycja">
                    <tr><td class="log4_t">[tytuł]</td><td><input type="text" name="title" class="edycja" /></td></tr>
                    <tr><td class="log4_t">[treść]</td><td><textarea id="content" name="content">

                    </textarea>
                    <tr><td>&nbsp;</td><td><input type="checkbox" name="x0_submit" class="edycja" value="Aktywna" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="edycja" value="Zatwierdź" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x2_submit" class="edycja" value="Odrzuć" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';

    return $wynik;
}

function mysqlInsertVal($title, $content)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "INSERT INTO page_list (page_title, page_content) VALUES ($title, $content)";
    mysqli_query($link, $query);
}

function DodajProdukt()
{
    $wynik = '
    <div class="dodaj">
        <h1 class="heading">Dodaj Produkt:</h1>
            <div class="dodaj">
            <form method="post" name"AddForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="dodaj">
                    <tr><td class="log4_t">[tytuł]</td><td>'.$title='<input type="text" name="title" class="edycja" /></td></tr>
                    <tr><td class="log4_t">[treść]</td><td>'.$content='<textarea id="content" name="content">

                    </textarea>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="edycja" value="Zatwierdź" onsubmit="mysqlInsertVal($title, $content);"/></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x2_submit" class="edycja" value="Odrzuć" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';

    return $wynik;
}

function UsunProdukt($id)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);
    $query = "DELETE FROM produkty WHERE id=$id";
    mysqli_query($link, $query);
}

?>