<?php
	$nr_indeksu = '164345';
	$nrGrupy = 'I';
	$color = 'red';
	$fruit = 'apple';
?>