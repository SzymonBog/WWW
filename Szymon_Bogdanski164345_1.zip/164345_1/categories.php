<?php

function mysqlInsertCat($id, $matka, $nazwa)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "INSERT INTO categories (id, matka, nazwa) VALUES ($id, $matka, $nazwa)";
    mysqli_query($link, $query);
}

function DodajKategorie(){
    $wynik = '
    <div class="dodaj">
        <h1 class="heading">Panel CMS:</h1>
            <div class="dodaj">
            <form method="post" name"AddForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="dodaj">
                    <tr><td class="log4_t">[id]</td><td>'.$id='<input type="text" name="id" class="edycja" /></td></tr>
                    <tr><td class="log4_t">[matka]</td><td>'.$matka='<input type="text" name="matka">
                    <tr><td class="log4_t">[nazwa]</td><td>'.$nazwa='<input type="text" name="nazwa">

                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="edycja" value="Zatwierdź" onsubmit="mysqlInsertCat($id, $matka, $nazwa);"/></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x2_submit" class="edycja" value="Odrzuć" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';

    echo $wynik;
}

function UsunKategorie($id){
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);
    $query="DELETE categories WHERE id='$id'";
    mysqli_query($link, $query);
}

function EdytujKategorie($id, $matka, $nazwa){
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);
    $query="UPDATE categories SET matka=$matka, nazwa=$nazwa WHERE id=$id";
    mysqli_query($link, $query);
}

function PokazKategorie(){
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);
    $query="SELECT * FROM categories";
    $resp = mysqli_query($link, $query);
    foreach ($resp as $key => $value) {
        echo $key;
    }
    return $resp;
}
?>