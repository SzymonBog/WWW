<?php

include("cfg.php");

function FormularzLogowania()
{
    $wynik = '
    <div class="logowanie">
        <h1 class="heading">Panel CMS:</h1>
            <div class="logowanie">
            <form method="post" name"LoginForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="logowanie">
                    <tr><td class="log4_t">[email]</td><td><input type="text" name="login_email" class="logowanie" /></td></tr>
                    <tr><td class="log4_t">[haslo]</td><td><input type="password" name="login_pass" class="logowanie" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="logowanie" value="Zaloguj" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';
    return $wynik;
}

function ListaPodstron()
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "SELECT * FROM page_list LIMIT 100";
    $result = mysqli_query($link, $query);

    while($row = mysqli_fetch_array($result))
    {
        echo $row['id'].' '.$row['page_title'].' <br />';
    }
}

function EdytujPodstrone()
{
    $wynik = '
    <div class="edycja">
        <h1 class="heading">Panel CMS:</h1>
            <div class="edycja">
            <form method="post" name"EditForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="edycja">
                    <tr><td class="log4_t">[tytuł]</td><td><input type="text" name="title" class="edycja" /></td></tr>
                    <tr><td class="log4_t">[treść]</td><td><textarea id="content" name="content">

                    </textarea>
                    <tr><td>&nbsp;</td><td><input type="checkbox" name="x0_submit" class="edycja" value="Aktywna" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="edycja" value="Zatwierdź" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x2_submit" class="edycja" value="Odrzuć" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';

    return $wynik;
}

function mysqlInsert($title, $content)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "INSERT INTO page_list (page_title, page_content) VALUES ($title, $content)";
    mysqli_query($link, $query);
}

function DodajPodstrone()
{
    $wynik = '
    <div class="dodaj">
        <h1 class="heading">Panel CMS:</h1>
            <div class="dodaj">
            <form method="post" name"AddForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="dodaj">
                    <tr><td class="log4_t">[tytuł]</td><td>'.$title='<input type="text" name="title" class="edycja" /></td></tr>
                    <tr><td class="log4_t">[treść]</td><td>'.$content='<textarea id="content" name="content">

                    </textarea>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="edycja" value="Zatwierdź" onsubmit="mysqlInsert($title, $content);"/></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x2_submit" class="edycja" value="Odrzuć" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';

    return $wynik;
}

function UsunPodstrone($id)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);
    $query = "DELETE FROM page_list WHERE id=$id";
    mysqli_query($link, $query);
}

//                     <tr><td class="log4_t">[treść]</td><td><input type="text" name="login_passwd" class="edycja" /></td></tr>

?>