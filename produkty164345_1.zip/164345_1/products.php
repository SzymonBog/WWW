<?php
function PokazProdukty()
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "SELECT * FROM produkty LIMIT 100";
    $result = mysqli_query($link, $query);

    while($row = mysqli_fetch_array($result))
    {
        $curid = $row['id'];
        $query1 = "SELECT nazwa FROM categories where id='$curid'";
        $kat = mysqli_query($link, $query1);
        echo $row['id'].' '.$row['tytul'].' <br />';
        echo $row['opis'].' '.$row['dataUtworzenia'].' '.$row['dataModyfikacji'].' '.$row['dataWygasniecia'].' <br />';
        echo $row['cenaNetto'].' '.$row['podatekVAT'].' <br />';
        echo $row['ilosc'].' '.$row['dostepnosc'].' '.$row['kategoria'].' '.$row['gabaryt'].' <br />';  // kategoria INT
        echo $row['zdjecie'].' <br />';
    }
}

function EdytujProdukt($id)
{

    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';

    // Create a database connection
    $link = new mysqli($dbhost, $dbuser, $dbpass, $db);

    // Check for connection errors
    if ($link->connect_error) {
        die("Connection failed: " . $link->connect_error);
    }

    if(isset($_POST['submit'])) {
        $id = $_POST['id'];
        $tytul = $_POST['tytul'];
        $opis = $_POST['opis'];
        $dataWyg = $_POST['dataWygasniecia'];
        $cenaNet = $_POST['cenaNetto'];
        $ilosc = $_POST['ilosc'];
        $kategoria = $_POST['kategoria'];
        $gabaryt = $_POST['gabaryt'];
        $zdjecie = $_POST['zdjecie'];

        // Call the function to update data in the database
        $query = "UPDATE produkty SET tytul=?, opis=?, dataWygasniecia=?, cenaNetto=?, ilosc=?, kategoria=?, gabaryt=?, zdjecie=? WHERE id=?";
        $stmt = $link->prepare($query);
        $stmt->bind_param("sssdiisbi", $tytul, $opis, $dataWyg, $cenaNet, $ilosc, $kategoria, $gabaryt, $zdjecie, $id);

        if($stmt->execute()) {
            echo "Zmodyfikowano";
        } else {
            echo "Error updating record: " . $stmt->error;
        }
        
        $stmt->close();

        //$currentURL = $_SERVER['REQUEST_URI'];
        if (isset($_GET['id'])){
            echo '<script>window.location.href = "http://localhost/164345/164345_1/index.php?id=96";</script>';
        } else {
            echo '<script>window.location.href = "http://localhost/164345/164345_1/index.php?idp=96";</script>';
        }
    }

    if (isset($_POST['reject'])){
        if (isset($_GET['id'])){
            echo '<script>window.location.href = "http://localhost/164345/164345_1/index.php?id=96";</script>';
        } else {
            echo '<script>window.location.href = "http://localhost/164345/164345_1/index.php?idp=96";</script>';
        }
    }

    // Fetch category details based on the provided ID
    $query = "SELECT * FROM produkty WHERE id = ?";
    $stmt = $link->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();

        // Pre-fill the form fields with fetched category values
        $id = $product['id'];
        $tytul = $product['tytul'];
        $opis = $product['opis'];
        $dataWyg = $product['dataWygasniecia'];
        $cenaNet = $product['cenaNetto'];
        $ilosc = $product['ilosc'];
        $kategoria = $product['kategoria'];
        $gabaryt = $product['gabaryt'];
        $zdjecie = $product['zdjecie'];

        // Generate the form with pre-filled values

        $wynik = '
        <div class="edycja">
            <h1 class="heading">Edytuj Produkt:</h1>
                <div class="edycja">
                <form method="post" name"EditForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                    <input type="hidden" name="id" value="'.$id.'">
                    <table class="edycja">
                        <tr><td class="log4_t">[tytuł]</td><td><textarea id="tytul" name="tytul">'.$tytul.'</textarea></td></tr>
                        <tr><td class="log4_t">[opis]</td><td><textarea id="opis" name="opis">'.$opis.'</textarea></td></tr>
                        <tr><td class="log4_t">[data wygasniecia]</td><td><input type="text" name="dataWygasniecia" value="'.$dataWyg.'"></td></tr>
                        <tr><td class="log4_t">[cena netto]</td><td><input type="text" name="cenaNetto" value="'.$cenaNet.'"></td></tr>
                        <tr><td class="log4_t">[ilosc]</td><td><input type="text" name="ilosc" value="'.$ilosc.'"></td></tr>
                        <tr><td class="log4_t">[kategoria(int)]</td><td><input type="text" name="kategoria" value="'.$kategoria.'"></td></tr>
                        <tr><td class="log4_t">[gabaryt]</td><td>
                        <form>
                        <select name="gabaryt">
                        <option value="duzy">duży</option>
                        <option value="sredni">średni</option>
                        <option value="maly">mały</option>
                        </select>
                        </form>
                        </td></tr>
                        <tr><td class="log4_t">[zdjecie]</td><td><input type="text" name="zdjecie" value="'.$zdjecie.'"></td></tr>

                        <tr><td>&nbsp;</td><td><input type="submit" name="submit" class="edycja" value="Zatwierdź" /></td></tr>
                        <tr><td>&nbsp;</td><td><input type="submit" name="reject" class="edycja" value="Odrzuć" /></td></tr>
                    </table>
                </form>
            </div>
        </div>
        ';

        return $wynik;
    } else {
        return 'Product not found.';
    }

    $stmt->close();
    $link->close();
}

function mysqlInsertVal($title, $content)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);

    //$query="SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
    $query = "INSERT INTO page_list (page_title, page_content) VALUES ($title, $content)";
    mysqli_query($link, $query);
}

function DodajProdukt()
{
    $wynik = '
    <div class="dodaj">
        <h1 class="heading">Dodaj Produkt:</h1>
            <div class="dodaj">
            <form method="post" name"AddForm" enctype="multipart/form-data" action="'.$_SERVER['REQUEST_URI'].'">
                <table class="dodaj">
                    <tr><td class="log4_t">[tytuł]</td><td>'.$title='<input type="text" name="title" class="edycja" /></td></tr>
                    <tr><td class="log4_t">[treść]</td><td>'.$content='<textarea id="content" name="content">

                    </textarea>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="edycja" value="Zatwierdź" onsubmit="mysqlInsertVal($title, $content);"/></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x2_submit" class="edycja" value="Odrzuć" /></td></tr>
                </table>
            </form>
        </div>
    </div>
    ';

    return $wynik;
}

function UsunProdukt($id)
{
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $db = 'moja_strona';
    //czyscimy $id, aby przez GET ktoś nie próbował wykonać ataku SQL INJECTION
    //$id_clear = htmlspecialchars($id);
    $link = new mysqli($dbhost,$dbuser,$dbpass,$db);
    $query = "DELETE FROM produkty WHERE id=$id";
    mysqli_query($link, $query);
}

?>